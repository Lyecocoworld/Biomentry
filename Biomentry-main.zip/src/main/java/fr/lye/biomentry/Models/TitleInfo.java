package fr.lye.biomentry.Models;

public class TitleInfo {
    public int FadeIn;
    public int Stay;
    public int FadeOut;
    public String AnimationType;
    public int TypewriterSpeed;
    public String Separator;
}
